package org.example;

import java.util.Arrays;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // OPERADORES
        int operador1=1;
        int operador2=15;
        int resultado =0;
        //resta(-)
        //division (/)
        //modulo(%) residuo de una division
        resultado = operador1 + operador2;
        System.out.println("resultado = " + resultado);

        }
    }
