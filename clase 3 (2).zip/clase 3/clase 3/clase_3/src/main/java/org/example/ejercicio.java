package org.example;
import java.util.Scanner;
public class ejercicio {
    public static void main(String[] args){
        //Entradas--> Cantidad inicial, Cantidad comprada, Cantidad vendida, Precio de compra
        //Salidas--> Precio de venta, Ingresos, Egresos, Ganacias brutas, Impuestos, Ganancias
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa cuanto tienes");
        int cantidad = sc.nextInt();
        System.out.println("Ingresa cuanto vas a gastar: ");
        int gasto = sc.nextInt();
        System.out.println("Ingresa cuanto vendiste: ");
        int venta = sc.nextInt();
        System.out.println("Ingresa cuanto fue el costo: ");
        int costo = sc.nextInt();
        
        final float iva = 0.18f;
        final float ganacia = 0.10f;
        
        
    }
}
