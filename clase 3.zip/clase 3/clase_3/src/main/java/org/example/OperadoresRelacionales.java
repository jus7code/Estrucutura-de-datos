package org.example;

public class OperadoresRelacionales {
    public static void main(String[] args){
        System.out.println("Operadores relacionales");
        int operador1=10;
        int operador2=20;
        int operador3=10;
        boolean resultado;
        resultado = operador1==operador2;
        resultado = operador1!=operador2;
        resultado = operador1<operador2;
        resultado = operador1>operador2;
        resultado = operador1>=operador2;
        resultado = operador1<=operador2;
        System.out.println("OPERADORES LOGICOS");
        resultado = operador1==operador2 && operador1<operador2;
        resultado = operador1==operador2 || operador1<operador2;
        resultado = (operador1==operador2 || operador1<operador2) && true;

        String myCadena = "mi moto alpina derrapante";
        System.out.println(myCadena.charAt(4));
        System.out.println(myCadena.endsWith("."));
        System.out.println(myCadena.equals(""));
        System.out.println(myCadena.length());
        System.out.println(myCadena.replace('a','a'));
        System.out.println(myCadena.replace('e','a'));
        System.out.println(myCadena.replace('i','a'));
        System.out.println(myCadena.replace('o','a'));
        System.out.println(myCadena.toLowerCase());
        System.out.println(myCadena.toUpperCase());
    }
}

