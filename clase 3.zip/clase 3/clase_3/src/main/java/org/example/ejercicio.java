package org.example;
import java.util.Scanner;
public class ejercicio {
    public static void main(String[] args){
        //Entradas--> Cantidad inicial, Cantidad comprada, Cantidad vendida, Precio de compra
        //Salidas--> Precio de venta, Ingresos, Egresos, Ganacias brutas, Impuestos, Ganancias
        Scanner sc = new Scanner(System.in);

    }
}
